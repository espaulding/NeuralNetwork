﻿/*
 * Eric Spaulding, Graduate Student
 * Professor Doug Raiford
 * Machine Learning - Spring 2014
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Classifier {
    public class Value {
        public double value;

        public Value(double v) {
            value = v;
        }
    }
}
